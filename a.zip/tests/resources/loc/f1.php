<?php
// comment 1
// comment 1
function twice($a) {
    if(true) {

    } else {
        
    }
    return 2 * $a;
}

/*function twice($a) {
    return 2 * $a;
}*/



function triple($a) {
    return 3 * $a;
}

//function triple($a) {
//    return 3 * $a;
//}

/**
function triple($a) {
    return 3 * $a;
}


 *
 * */