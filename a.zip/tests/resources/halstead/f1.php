<?php
function twice($a) {
    return 2 * $a;
}