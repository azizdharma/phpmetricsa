<?php
function maxi ($a, $b){
    if ($a > $b) return $a;
    return $b;
}