<?php
while(
    ($token != 'var')
    && ($token != 'vars')
    && ($token != 'type')
    && ($token != 'function')
    && ($token != 'procedure')
    && ($token != 'begin')
    && ($token != 'label')
    && !$endOfFile
) {

}
