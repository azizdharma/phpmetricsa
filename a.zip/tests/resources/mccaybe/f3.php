<?php
switch($r) {
    case 1:

        break;
    case 2:

        break;

    default:

        break;
}