<?php
$username = isset($_GET['user']) ? $_GET['user'] : 'nobody';

