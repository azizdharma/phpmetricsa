<?php
if( c1() )
    f1();
else
    f2();

if( c2() )
    f3();
else
    f4();