<?php
echo 1 <=> 1;