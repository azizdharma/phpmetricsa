<?php
if(true) {
    if(true) {

    } else {
        foreach(array() as $x) {

        }
    }
}