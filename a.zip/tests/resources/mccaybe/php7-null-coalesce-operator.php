<?php
$username = $_GET['user'] ?? 'nobody';

