<?php
class Example {

}