<?php
class ExampleIncorrect {
    public
}