<?php
class A {
    private static function foo() {}
}