<?php
class A {
    public function foo(string $a, int $b)
    {

    }
}