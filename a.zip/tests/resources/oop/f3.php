<?php
namespace My\Example;
class Titi1 {
    
}
class Titi2 {

}