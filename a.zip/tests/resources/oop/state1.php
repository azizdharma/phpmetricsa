<?php
class A {
    function foo() {}
}