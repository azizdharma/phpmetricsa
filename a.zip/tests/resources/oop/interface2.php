<?php
namespace My;
interface Contract1 {}
interface Contract2 {}
class MyClass implements Contract1, Contract2 {

}