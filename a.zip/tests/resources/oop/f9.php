<?php
class classA

    extends classB {
}


class classC

    extends classD {
}