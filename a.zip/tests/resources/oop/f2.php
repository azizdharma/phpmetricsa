<?php
namespace My\Example;
class Titi {

    public function foo() {

    }

    public function bar(AnotherClass $c = null) {

    }

    public function baz(\Namespaced\AnotherClass       $c

        , AnotherClass $c2 = null) {

    }
}