<?php
interface Titi {

}