<?php
class A {
    public static function foo() {}
}