<?php
class A {
    function foo() {
        $this->baz();
        $this->bar();
    }
}