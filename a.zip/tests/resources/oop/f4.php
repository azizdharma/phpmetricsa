<?php
namespace My\Example;

use \Full\AliasedClass as Another;

class Titi {

    public function bar(Another &$t1, Toto $t2) {

    }

}
