<?php
namespace My\Example;


class Titi {

    public function foo($a) {
        $a = strtoupper((string)$a);
        return $a;
    }

    public function baz() {

        $x = 1 * 2;



        die();
    }
}