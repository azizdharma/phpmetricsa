<?php
class A {
    static public function foo() {}
}