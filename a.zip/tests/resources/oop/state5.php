<?php
class A {
    public function foo() {}
}