<?php
class A {
    static protected function foo() {}
}