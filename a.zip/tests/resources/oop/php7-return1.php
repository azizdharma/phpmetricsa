<?php
namespace My;
class Class1 {
    public function foo(): array {
    }
}
