<?php
class A {
    static function foo() {}
}