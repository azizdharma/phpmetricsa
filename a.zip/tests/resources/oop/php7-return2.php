<?php
namespace My;

class Class1 {
    public function foo(): Class2 {
    }
}


class Class2 {

}