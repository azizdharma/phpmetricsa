<?php
abstract class Titi {

}