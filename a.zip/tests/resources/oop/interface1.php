<?php
interface Contract1 {}
class MyClass implements Contract1


    {

}